#!/usr/bin/env python3

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns 
sns.set()
DPI = 100

data = np.loadtxt('data/generated/sample_030.csv', delimiter=',')
X, y = data[:,0], data[:,1]   

plt.plot(X,y,'o');
#plt.plot(X,true_fun(X))
plt.xlabel("x")
plt.ylabel("y")
plt.xlim((0, 1))
plt.ylim((-1.5, 1.5))
plt.savefig('generated_points_30.pdf', dpi=DPI, bbox_inches='tight')